#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

class Solution {
  public:
    bool isPalindrome(int x) {
      return true;         
    }
};
